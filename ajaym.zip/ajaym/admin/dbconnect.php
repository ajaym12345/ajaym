<?php

	$link=mysqli_connect("localhost","root","","ajaym") or die("Error: cannot establish database connection :(".mysqli_connect_error());

?>